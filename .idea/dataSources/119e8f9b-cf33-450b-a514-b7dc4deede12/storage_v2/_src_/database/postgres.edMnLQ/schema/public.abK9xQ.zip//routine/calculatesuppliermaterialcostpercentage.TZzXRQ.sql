create procedure calculatesuppliermaterialcostpercentage(IN supplierid integer, OUT percentage numeric)
    language plpgsql
as
$$
DECLARE
    totalCost NUMERIC;
    supplierCost NUMERIC;
BEGIN
    -- Calculate the total cost of all materials
    SELECT SUM(material_cost * material_amount) INTO totalCost
    FROM public.material;

    -- Calculate the total cost of materials for the given supplier
    SELECT SUM(material_cost * material_amount) INTO supplierCost
    FROM public.material
    WHERE supplier_id = supplierId;

    -- Calculate the percentage
    IF totalCost > 0 THEN
        percentage := (supplierCost / totalCost) * 100;
    ELSE
        percentage := 0;
    END IF;
END;
$$;

alter procedure calculatesuppliermaterialcostpercentage(integer, out numeric) owner to postgres;

