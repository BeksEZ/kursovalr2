create function check_material_amount() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.material_units = 'piece' AND NEW.material_amount % 1 != 0 THEN
        RAISE EXCEPTION 'Material amount must be a whole number when units are "piece".';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_material_amount() owner to postgres;

