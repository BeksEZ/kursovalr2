create function update_contract_sum() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.pay_type = 1 OR NEW.pay_type = 2 THEN
            UPDATE public.contract
            SET contract_sum = contract_sum - NEW.pay_sum
            WHERE contract_id = NEW.contract_id;
        ELSIF NEW.pay_type = 3 THEN
            UPDATE public.contract
            SET contract_sum = contract_sum + NEW.pay_sum
            WHERE contract_id = NEW.contract_id;
        END IF;
    ELSIF TG_OP = 'UPDATE' THEN
        IF NEW.pay_type = 1 OR NEW.pay_type = 2 THEN
            UPDATE public.contract
            SET contract_sum = contract_sum - NEW.pay_sum
            WHERE contract_id = NEW.contract_id;
        ELSIF NEW.pay_type = 3 THEN
            UPDATE public.contract
            SET contract_sum = contract_sum + NEW.pay_sum
            WHERE contract_id = NEW.contract_id;
        END IF;
    ELSIF TG_OP = 'DELETE' THEN
        IF OLD.pay_type = 1 OR OLD.pay_type = 2 THEN
            UPDATE public.contract
            SET contract_sum = contract_sum + OLD.pay_sum
            WHERE contract_id = OLD.contract_id;
        ELSIF OLD.pay_type = 3 THEN
            UPDATE public.contract
            SET contract_sum = contract_sum - OLD.pay_sum
            WHERE contract_id = OLD.contract_id;
        END IF;
    END IF;
    
    RETURN NULL;
END;
$$;

alter function update_contract_sum() owner to postgres;

