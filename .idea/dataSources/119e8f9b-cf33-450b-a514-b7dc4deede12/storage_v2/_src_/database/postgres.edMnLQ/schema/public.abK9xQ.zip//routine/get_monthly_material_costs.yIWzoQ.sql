create procedure get_monthly_material_costs()
    language plpgsql
as
$$
DECLARE
    month_date date;
    total_cost numeric(20,2);
    monthly_costs_cursor CURSOR FOR
    SELECT
        DATE_TRUNC('month', l.date_start) AS month_date,
        SUM(um.amount * m.material_cost) AS total_cost
    FROM
        used_materials um
    JOIN
        labor l ON um.labor_id = l.labor_id
    JOIN
        material m ON um.material_id = m.material_id
    GROUP BY
        DATE_TRUNC('month', l.date_start)
    ORDER BY
        month_date;
BEGIN
    -- Відкриття курсора
    OPEN monthly_costs_cursor;
    
    -- Виведення результатів курсора
    LOOP
        FETCH monthly_costs_cursor INTO month_date, total_cost;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Month: %, Total Cost: %', month_date, total_cost;
    END LOOP;

    -- Закриття курсора
    CLOSE monthly_costs_cursor;
END;
$$;

alter procedure get_monthly_material_costs() owner to postgres;

