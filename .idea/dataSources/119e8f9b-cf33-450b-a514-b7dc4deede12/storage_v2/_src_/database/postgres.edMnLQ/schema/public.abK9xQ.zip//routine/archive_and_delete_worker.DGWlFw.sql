create function archive_and_delete_worker() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO  archive_assignments (labor_id, job_id, building_id, fullname, worker_payinfo, real_hours, required_hours)
    SELECT a.labor_id, OLD.job_id, OLD.building_id, OLD.fullname, OLD.worker_payinfo, a.real_hours, a.required_hours
    FROM  assignment a
    WHERE a.worker_id = OLD.worker_id;

    INSERT INTO  archive_pay (pay_id, pay_type, required_id, pay_sum, pay_date, contract_id)
    SELECT p.pay_id, p.pay_type, p.required_id, p.pay_sum, p.pay_date, p.contract_id
    FROM  pay p
    WHERE p.required_id = OLD.worker_id AND p.pay_type = 1;
    DELETE FROM  assignment WHERE worker_id = OLD.worker_id;
    DELETE FROM  pay WHERE required_id = OLD.worker_id;
    RETURN OLD;
END;
$$;

alter function archive_and_delete_worker() owner to postgres;

